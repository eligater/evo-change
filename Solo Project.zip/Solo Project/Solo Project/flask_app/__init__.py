from flask import Flask

app = Flask(__name__)

app.secret_key = 'B8h24koO914DGlW0'