var introDiv = document.querySelector(".intro");

function accept() {
    introDiv.remove();
}

var  choiceDiv = document.querySelector(".choice");

function add(num){
    choiceDiv = parseInt(choiceDiv)+num

    let a = 3
    let b = 4
    let c = 7
    
    if (a => 10) {


}

}

//if its under 10 the images decrease but if its 10 to 15 it stays the same, 15 to over it increases 
//