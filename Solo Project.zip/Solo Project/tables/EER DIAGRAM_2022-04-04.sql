# ************************************************************
# Sequel Ace SQL dump
# Version 20033
#
# https://sequel-ace.com/
# https://github.com/Sequel-Ace/Sequel-Ace
#
# Host: 127.0.0.1 (MySQL 8.0.27)
# Database: EER DIAGRAM
# Generation Time: 2022-04-04 23:34:34 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
SET NAMES utf8mb4;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE='NO_AUTO_VALUE_ON_ZERO', SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table paintings
# ------------------------------------------------------------

DROP TABLE IF EXISTS `paintings`;

CREATE TABLE `paintings` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `painted_by` text,
  `user_id` int DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `price` decimal(10,0) DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `user_id` FOREIGN KEY (`id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;



# Dump of table users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `password`, `created_at`, `updated_at`)
VALUES
	(1,'',NULL,NULL,'12345678',NULL,NULL),
	(2,'diva','moon','diva.moon@gmail.com','$2b$12$QC4TLN/L6oucUzAxKmhv3eDB9Pxapz65/.DUn/dTQ481RvO.nwvpe',NULL,NULL),
	(3,'elie','knight','elie.knight@gmail.com','$2b$12$SABc954BbAb8NdqKPd/42ufGjcGD1kc7Fsf3QYmj8.9v/tklokb.2',NULL,NULL),
	(4,'kate','kitkate','kate@gmail.com','$2b$12$PLgbEeHSA.Fc.hyCioM0wOfdAcbOVlhpTZ5ikQhZVZj0yP9fJINwS',NULL,NULL),
	(5,'roadie','iscute','rodie@gmail.com','$2b$12$bcNkVkhhgMDQQra3QrmXFuRRlmYcizro5K6/hImZPu/cX8FZoWRVe',NULL,NULL),
	(6,'eliee','knighth','roadiei@gamil.com','$2b$12$Lt44y0b8TA8ohppYia81QeQbRYjJXo7AmzCdXyA7LAK.R4oapKdiG',NULL,NULL),
	(7,'123123','123123','123123@gmail.com','$2b$12$ozokkSMJ5DnsVl4kIXa7numSsRUFKliEH73stue0GbjGNAHyO6fYq',NULL,NULL),
	(8,'111','111','111@gmail.com','$2b$12$n0mPEzlR6ATxrrIbx78zeO3o3PL1HnHdNf.p1Zn8.cNm3QCIh92wy',NULL,NULL),
	(9,'222','222','222@gmail.com','$2b$12$u.RhdLcl.dyNQ653Yxe6KeLV/KFw.b3oXq9uI4YbLLdjx4L9kFPhe',NULL,NULL),
	(10,'eli','kni','eli.kni@gmail.com','$2b$12$TGYTiEPcf49NNMun6wi3WOdfHxYuBsyc5M8XQcC3tfrQCYptFauD6',NULL,NULL),
	(11,'elli','knigh','elli@gmail.com','$2b$12$EU4YXYHkI.5Zh1KNCgApg.CZ0KJxPvLOvugX6g7L.J2ZQh4rZMaUa',NULL,NULL),
	(12,'pip','pip','pip@gmail.com','$2b$12$AJ2T2wG1GSR6lHH.8exyPuI/xijONAF6qdxIca1SxUx1MoDoYotRK',NULL,NULL);

/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
